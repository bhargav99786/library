<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Student registration form</title>
<link rel='stylesheet' href='css/form.css' type='text/css' />
<script src="js/form.js"></script>
</head>
<body onload="document.registration.Enrollment.focus();">
    <div class="wrapper">
        <div class="inner">
            <h1 style="text-align: center;">Forget Password</h1>
            <form name='registration' action="forgetpassword1.php" method="post" >
                <?php if (isset($_GET['error'])) { ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                <?php } ?>
                <label class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="Email id" >
                </label>
                <b style="color: rgb(0, 3, 179); ">Note: </b><span style="color: rgb(177, 177, 212); ">You Get Your User id and password in Mail</span>
                <button type="submit" class="zmdi zmdi-arrow-right" name="submit">Submit </button>
            </form>
        </div>
    </div>
</body>
</html>