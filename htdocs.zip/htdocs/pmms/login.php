<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Student registration form</title>
<link rel='stylesheet' href='css/form.css' type='text/css' />
<script src="js/form.js"></script>
</head>
<body onload="document.registration.Enrollment.focus();">
    <div class="wrapper">
        <div class="inner">
            <h1 style="text-align: center;">Login</h1>
            <form name='registration' action="loginvalid.php" method="post">
                <?php if (isset($_GET['error'])) { ?>
                    <p class="error" style="color=red"><?php echo $_GET['error']; ?></p>
                <?php } ?>
                <label class="form-group">
                    <input type="text" class="form-control" name="uname" placeholder="Enrollment Number" >
                </label>
                <label class="form-group">
                    <input type="password" class="form-control" name="password" placeholder="Password" >
                </label>
                <a href="./forgetpassword.php"style="color: rgb(177, 177, 212);"><span>I forgotten my password</span></a><br>
                <a href="./form.php"style="color: rgb(177, 177, 212);"><span>register my self</span></a>
                <button type="submit" class="zmdi zmdi-arrow-right" name="submit">Login </button>
            </form>
        </div>
    </div>
</body>
</html>