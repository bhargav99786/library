function formValidation()
{
var uid = document.registration.enrollment;
var username1 = document.registration.username;
var contact1 = document.registration.contact;
var uemail = document.registration.email;
var dob = document.registration.dateofbirth;
if(userid_validation(uid))
{
if(alphanumeric(username1))
{
if(contact_validation(contact1))
{
if(email_validation(uemail))
{
if(dob_validation(dob))
{
}
}
}
}
}
return false;
}
function userid_validation(uid)
{
var numericer = /^[0-9]+$/;
var uid_len = uid.value.length;
if (uid_len == 0 || uid_len >= 13  )
{
alert("Enrollment Number 12 Digit ");
uid.focus();
return false;
}
else(uid.value.match(numericer))
{
    return true;
}
}


function alphanumeric(username1)
{ 
var letters = /^[a-zA-Z]+$/;
if(username1.value.match(letters))
{
    return true;
}
else
{
    alert('Enter Your Full name');
    username1.focus();
    return false;
}
}


function contact_validation(contact1)
{
var numericer = /^[0-9]+$/;
var contact2 = contact1.value.length;
if(contact1.value.match(numericer) &&( contact2 ==10 || contact2 == 13))
{
return true;
}
else
{
alert('Enter Your  10 digit contact number');
contact1.focus();
return false;
}
}


function email_validation(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
}

function dob_validate(dob)
{
    return false;
}

