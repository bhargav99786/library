<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Main Pagge</title>
        <meta name="description" content="">
        <!-- 
    	Volton Template
    	http://www.templatemo.com/tm-441-volton
        -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="portal/web/css/normalize.css">
        <link rel="stylesheet" href="portal/web/css/font-awesome.css">
        <link rel="stylesheet" href="portal/web/css/bootstrap.min.css">
        <link rel="stylesheet" href="portal/web/css/templatemo-style.css">
        <script src="portal/web/js/vendor/modernizr-2.6.2.min.js"></script>
        <style>
body {
  background-image: url('portal/web/img/profile.png');
  background-repeat: no-repeat;
  padding-left:600px;
}
</style>
    </head>
    <body>
       
        <!-- SIDEBAR -->
        <div class="sidebar-menu " style="overflow-y:scroll,width:800px">
            <div class="top-section">
                <div class="profile-image">
                    <img src="portal/web/img/profile.png" style="margin:12px" alt="Volton">
                </div>
                <h3 class="profile-title" style="text-align:center"></h3>
                <p class="profile-description" style="text-align:center"></p>
            </div> <!-- top-section -->
            <div class="main-navigation">
                <ul class="navigation" >
                    <li><a href="form.php">Registration For Student</a></li>
                    <li><a href="teacherform.php">Registration for Student</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="forgetpassword.php">Forget Password</a></li>
                </ul>
            </div> <!-- .main-navigation -->
        </div>
        <div>
            
        </div>
        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/min/plugins.min.js"></script>
        <script src="js/min/main.min.js"></script>
    </body>
</html>