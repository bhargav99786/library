<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Student registration form</title>
<link rel='stylesheet' href='css/form.css' type='text/css' />
<script src="js/form.js"></script>
</head>
<body onload="document.registration.enrollment.focus();">
    <div class="wrapper">
        <div class="inner">
            <h1 style="text-align: center; color: cornsilk;">Student Registration Form</h1>
            <form name='registration' action="./php/insert.php" method="post" enctype="multipart/form-data" >
                <label class="form-group">
                    <input type="text" class="form-control" name="enrollment"  placeholder="Enrollment Number" required >
                </label>
                <label class="form-group">
                    <input type="text" class="form-control" name="username" placeholder="Surname Firstname Middlename" required >
                </label>
                <label class="form-group">
                    <input type="text" class="form-control" name="contact" placeholder="Contact Number"  required>
                </label>
                <label class="form-group">
                    <input type="text" class="form-control" name="email" placeholder="Email id"required >
                </label>
                <label class="form-group">
                    <input type="date" class="form-control" name="dateofbirth" required >
                </label>
                <label class="form-group" >
                    <input type="radio" name="gender" value="Male" required /><span>Male</span>
                    <input type="radio" name="gender" value="Female"  required/><span>Female</span>
                </label>
                <label class="form-group">
                <select name="department" required >
                    <option selected="" value="" > Department</option>
                    <option value="Computer">Computer</option>
                    <option value="IT">IT</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Civil">Civil</option>
                    <option value="Electrical">Electrical</option>
                    </select>
                </label>
                <label class="form-group"  >
                <select name="semester" required >
                    <option selected="" value="">Semester</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    </select>
                </label>
                <label class="form-group" >
                    <textarea name="Address" id="" class="form-control" placeholder="Full Address"  required></textarea>
                </label>
                <input type="checkbox" name="en" value="en" checked required /><span>I Agree to privacy of this project</span>
                <button type="submit" class="zmdi zmdi-arrow-right" name="submit" value="Submit">Submit </button>
              
            </form>
        </div>
    </div>
</body>
</html>