<?php
include_once '../php/database.php';
$sql="SELECT * FROM `attendance` WHERE `PRESENT`='0'";
if($result = $conn->query($sql)){
    while ($row = $result->fetch_assoc() ) {
        $UID=$row['UID'];
        $date=$row['DATE'];
        $day=$row['DAY'];
        $sql2="SELECT ENROLLMENT from user_data INNER JOIN attendance on user_data.UID=$UID LIMIT 1;";
        $sql3="SELECT ENROLLMENT from teacher_data INNER JOIN attendance on teacher_data.UID='$UID' LIMIT 1;";
        if(($result1 = $conn->query($sql2))){
            while(($row2 = $result1->fetch_assoc())){
                $enrollment=$row2['ENROLLMENT'];
                require_once 'calculate.php';
                cal($UID,$date,$day,$enrollment);
            }
        }
        elseif(($result2 = $conn->query($sql3))){
            while(($row3 = $result2->fetch_assoc())){
                $enrollment=$row3['ENROLLMENT'];
                require_once 'calculate.php';
                cal($UID,$date,$day,$enrollment);
            }
        }
        
    }
}
?>