<html>
<title>userProfile.php</title>
<body>
 <?php
     session_start();
     $username = $_SESSION['ENROLLMENT'] ;
     $name=$_SESSION['name'];
     $UID1 = $_SESSION['UID'];
     //retrieve the session variable
 ?>
 
 <div style="text-align:center"><h1>User Profile</h1></div>
 <br/>
 
 <div style="font-weight:bold"> Welcome <?php echo $name ?> </div>
  <h1><?php echo $username ?> </h1>
 <div style="text-align: right"><a href="../Logout.php">Logout</a></div> <!-- calling Logout.php to destroy the session -->
 
 <?php
 if(!isset($_SESSION['ENROLLMENT'])) //If user is not logged in then he cannot access the profile page
 {
     //echo 'You are not logged in. <a href="login.php">Click here</a> to log in.';
     header("location: ../login.php");
 }
 ?>
 <?php
    include 'calculate.php';
?>
</body>
</html>