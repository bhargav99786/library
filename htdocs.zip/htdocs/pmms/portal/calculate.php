<?php 

function cal($UID,$date,$day,$id){
    $host = 'localhost:3306';  
$user = 'root';  
$pass = '';  
$dbname = 'esp8266'; 
$conn = mysqli_connect($host, $user, $pass,$dbname);  
$sql1= "SELECT * FROM `attendance` WHERE  UID='$UID' AND DATE='$date'";
$sql2= "SELECT * FROM `attendance` WHERE  UID='$UID' AND DATE='$date' AND PRESENT ='0' LIMIT 2 ";
$sql3= "SELECT * FROM `attendance` WHERE  UID='$UID' AND DATE='$date' AND PRESENT ='0' LIMIT 1 ";
if($result2 = $conn->query($sql2)){
    while ($row2 = $result2->fetch_assoc()) {
        $result3 = $conn->query($sql3);
        $row2 = $result2->fetch_assoc();
        $row3 = $result3->fetch_assoc();
        $time1= new DateTime($row2['TIME']);
        $time2= new DateTime($row3['TIME']);
        $t1=$row2['TIME'];
        $t2=$row3['TIME'];
        $interval = $time2->diff($time1);
        $diffInMinutes = $interval->i; //23
        $diffInHours   = $interval->h; //8
        $minute= $diffInMinutes+($diffInHours*60);
    
    if($minute <= 70){
        $sql4= "SELECT * FROM `timetable` WHERE `day`='$day' and start >= '$t2' and end <= '$t1'";
        if($result4 = $conn->query($sql4)){
            $row4 = $result4->fetch_assoc();
            $day1 = $row4['day'];
            $sub = $row4['subject'];
            echo $id;
            $sql5= "INSERT INTO `$id`( `DAY`, `DATE`, `SUBJECT`)
            VALUES('$day1','$date','$sub')";
            $sql8= "INSERT INTO `$sub`( `DAY`, `DATE`, `enrollment`)
            VALUES('$day1','$date','$id')";
            $result8 = $conn->query($sql8);
            if($result5 = $conn->query($sql5)){
                $sql6= "UPDATE `attendance` SET `present`='1'  WHERE  UID='$UID' AND DATE='$date' LIMIT 1 ";
                $sql7= "UPDATE `attendance` SET `present`='1'  WHERE  UID='$UID' AND DATE='$date' LIMIT 2 ";
                $result6 = $conn->query($sql6);
                $result7 = $conn->query($sql7);
            }
            else{
                echo $conn -> error;
            }
        }
        else{
            echo $conn -> error;
        }
    } 
    elseif($minute >=90) {
        $sql4= "SELECT * FROM `timetable` WHERE `day`='$day' and start >= '$t2' and end <= '$t1'";
        if($result4 = $conn->query($sql4)){
            while($row4 = $result4->fetch_assoc()){
            $day1 = $row4['day'];
            $sub = $row4['subject'];
            echo $sub;
            echo $day1;
            $date1 =date("Y-m-d");
            $sql5= "INSERT INTO `$id`( `DAY`, `DATE`, `SUBJECT`)
            VALUES('$day1','$date1','$sub')";
            if($result5 = $conn->query($sql5)){
                $sql6= "UPDATE `attendance` SET `present`='1'  WHERE  UID='$UID' AND DATE='$date' LIMIT 1 ";
                $sql7= "UPDATE `attendance` SET `present`='1'  WHERE  UID='$UID' AND DATE='$date' LIMIT 2 ";
                $result6 = $conn->query($sql6);
                $result7 = $conn->query($sql7);
            }
        }
    }
        
    }
}
}
else{
    echo $conn -> error;
}
}
?>