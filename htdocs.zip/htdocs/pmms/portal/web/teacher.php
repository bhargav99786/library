<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Teacher</title>
        <meta name="description" content="">
        <!-- 
    	Volton Template
    	http://www.templatemo.com/tm-441-volton
        -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/templatemo-style.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <?php
          
        ?>
        <?php
            session_start();
            include '../../php/connection.php';
                $ENROLLMENT = $_SESSION['ENROLLMENT'] ;
                $name = $_SESSION['name'] ;
                $UID = $_SESSION['UID'] ;
                $DOB = $_SESSION['DOB'] ;
                $EMAIL = $_SESSION['EMAIL'] ;
                $CONTACT = $_SESSION['CONTACT'] ;
                $GENDER = $_SESSION['GENDER'] ;
                $DEPARTMENT = $_SESSION['DEPARTMENT'] ;
                $SEMESTER = $_SESSION['SEMESTER'] ;
                $ADDRESS = $_SESSION['ADDRESS'] ;
                $subject = $_SESSION['subject'];
                if(!isset($_SESSION['ENROLLMENT'])) //If user is not logged in then he cannot access the profile page
                {
                  //echo 'You are not logged in. <a href="login.php">Click here</a> to log in.';
                  header("location: ../../login.php");
                }
     //retrieve the session variable
        ?>
        <!-- SIDEBAR -->
        <div class="sidebar-menu " style="overflow-y:scroll">
            <div class="top-section">
                <div class="profile-image">
                    <img src="img/profile.png" style="margin:12px" alt="Volton">
                </div>
                <h3 class="profile-title" style="text-align:center"><?php echo $name;?></h3>
                <p class="profile-description" style="text-align:center"><?php echo $ENROLLMENT;?></p>
            </div> <!-- top-section -->
            <div class="main-navigation">
                <ul class="navigation" >
                    <li><a href="#top"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                    <li><a href="#report"><i class="fa fa-file-text"></i>Report</a></li>
                    <li><a href="#marks"><i class="fa fa-list-alt"></i>Mark</a></li>
                    <li><a href="#about"><i class="fa fa-user"></i>Time Table</a></li>
                    <li><a href="#contact"><i class="fa fa-phone"></i>Attendance</a></li>
                </ul>
                <ul>
                    <li><a href="logout.php"><i class="fa fa-sign-out"></i>Logout</a></li>
                </ul>
            </div> <!-- .main-navigation -->
        </div> <!-- .sidebar-menu -->
        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="fluid-container">
                <div class="content-wrapper">
                    <!-- ABOUT -->
                    <div class="page-section">
                    
                            <div class="boundry" id="top">
                              <div class="right">
                                <h1><?php
                                  echo date("jS \of F Y") . "<br>";
                                  $day = date("l");
                                  echo  $day. "<br>";
                                ?></h1>
                                </div>
                                <h6 style="color:#143d59;font-size: 25px;">Today Time Table</h6>
                               
                              <h6 style="color:#143d59;font-size: 25px;">Last Attendance</h6>
                              <table class="table" style="color:#143d59">
                                 <tr>
                                   <th width="30%">Day</th>
                                   <td width="30%">09 to 10</td>
                                   <td width="30%">11 to 12</td>
                                 </tr>
                                 <tr>
                                   <th width="30%">
                                     <?php 
                                     echo $day;
                                     include '../../php/connection.php';
                                     $sql="SELECT `subject`, `faculty` FROM `timetable` WHERE `day`='$day'";
                                     if($day=='Sunday'){
                                      $sub="Holiday";
                                      $sub1="Holiday";
                                      $fac="Holiday";
                                      $fac1="Holiday";
                                     }
                                     elseif($day=='Saturday'){
                                      $sub="Holiday";
                                      $sub1="Holiday";
                                      $fac="Holiday";
                                      $fac1="Holiday";
                                     }
                                     if(($result = $conn->query($sql)))
                                     {
                                      while(($row = $result->fetch_assoc()))
                                      {
                                          $sub=$row['subject'];
                                          $fac=$row['faculty'];
                                      }
                                     }
                                     $sql1="SELECT `subject`, `faculty` FROM `timetable` WHERE `day`='$day' LIMIT 1";
                                     if(($result1 = $conn->query($sql1)))
                                     {
                                      while(($row1 = $result1->fetch_assoc()))
                                      {
                                          $sub1=$row1['subject'];
                                          $fac1=$row1['faculty'];
                                      }
                                     }
                                     ?></th>
                                   <td width="30%">
                                     <?php 
                                     echo $sub1;
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                     echo $sub;
                                     ?>
                                   </td>
                                 </tr>
                                 <tr>
                                   <th width="30%">Faculty</th>
                                   <td width="30%">
                                     <?php 
                                     echo $fac1;
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                     echo $fac;
                                     ?>
                                   </td>
                                 </tr>
                              </table>
                            </div>
                            <div style="width: 10px;height:20px;" id="report" >

                            </div>
                           <div class="boundry" style="overflow-y:scroll">
                           <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                            <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Enrollment</th>
                        <th>DAY</th>
                        <th>DATE</th>
                        
                      </tr>
                    </thead>
                
                    <tbody>
                    <form method="post">
                    Start date: <input type="date" name="date"><br>
                   
                    <input type="submit">
                    </form>
                  <?php
                  if (isset($_POST['date']))
                  {
                        $date=$_POST['date'];
                      $sql4 = "SELECT * FROM `$SEMESTER` where DATE='$date' ";
                      $rs4 = mysqli_query($conn, $sql4);
                      $num4 = mysqli_num_rows($rs4);
                      $sn=0;
                      $status="";
                      if($num4 > 0)
                      { 
                        while ($rows4 = $rs4->fetch_assoc())
                          {
                             $sn = $sn + 1;
                            echo"
                              <tr>
                                <td>".$sn."</td>
                                <td>".$rows4['enrollment']."</td>
                                <td>".$rows4['DAY']."</td>
                                <td>".$rows4['DATE']."</td>
                               
                               </tr>";
                          }
                      }
                      else
                      {
                           echo   
                           "<div class='alert alert-danger' role='alert'>
                            No Record Found!
                            </div>";
                      }
                  }
                      ?>
                    </tbody>
                    </table>
                            </div>
                            <div style="width: 30px;height:20px;" id="marks"></div>
                           <div class="boundry" style="overflow-y:scroll" >
                           <form method="post">
                   <div>
                  <?php
                     
                     if (isset($_GET['Id']) && isset($_GET['action']) && $_GET['action'] == "edit")
                     {
                           $Id= $_GET['Id'];
                     
                           $query=mysqli_query($conn,"SELECT * FROM `marks` WHERE `ENROLLMENT`='$Id'");
                           $row=mysqli_fetch_array($query);
                           
                      }
                    ?>
                    <div>
                        <label class="form-control-label">Enrollment<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="Enrollment" value="<?php echo $row['ENROLLMENT'];?>" id="exampleInputFirstName" >
                        </div>
                    </div>
                    <div>
                        <div>
                        <label class="form-control-label"><?php echo $SEMESTER;
                        ?><span class="text-danger ml-2">*</span></label>
                        <input type="text" class="form-control" name="marks" value="<?php echo $row[$SEMESTER];?>" id="exampleInputFirstName" >
                        </div>  
                    </div>
                  
                    
                    <button type="submit" name="mupdate" class="btn btn-warning">Update</button>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                   
                  </form>
                  <?php
                    if (isset($_POST['mupdate']))
                    {
                          
                          $mark=$_POST['marks'];
                          $query=mysqli_query($conn,"UPDATE `marks` SET `$SEMESTER`='$mark' WHERE `ENROLLMENT`='$Id'");

                          echo  "Marks Updated";
                         
                     }
                  ?>
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        
                        <th>Enrollment</th>
                        <th><?php
                        echo $SEMESTER;?>
                         <th>Edit</th>
                        
                      </tr>
                    </thead>
                
                    <tbody>

                  <?php
                      $sql = "SELECT * FROM `marks`";
                      $rs = mysqli_query($conn, $sql);
                      $num = mysqli_num_rows($rs);
                      $sn=0;
                      $status="";
                      if($num > 0)
                      { 
                        while ($rows = $rs->fetch_assoc())
                          {
                             $sn = $sn + 1;
                            echo"
                              <tr>
                                <td>".$sn."</td>
                                
                                <td>".$rows['ENROLLMENT']."</td><td>";
                                ?>
                                <?php
                                echo $rows[$SEMESTER];
                                ?>
                            
                                
                                <?php echo "</td><td><a href='?action=edit&Id=".$rows['ENROLLMENT']."'><i>edit</i></a></td>
                               </tr>";
                          }
                      }
                      else
                      {
                           echo   
                           "<div class='alert alert-danger' role='alert'>
                            No Record Found!
                            </div>";
                      }
                      
                      ?>
                    </tbody>
                  </table>
                            </div>
                            <div style="width: 30px;height:20px;" id="about"></div>
                            <div class="boundry" style="overflow-y:scroll">
                            
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Day</th>
                        <th>Subject</th>
                        <th>Faculty</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        
                      </tr>
                    </thead>
                
                    <tbody>

                  <?php
                      $sql1 = "SELECT * FROM `timetable`";
                      $rs1 = mysqli_query($conn, $sql1);
                      $num1 = mysqli_num_rows($rs1);
                      $sn=0;
                      $status="";
                      if($num1 > 0)
                      { 
                        while ($rows1 = $rs1->fetch_assoc())
                          {
                             $sn = $sn + 1;
                            echo"
                              <tr>
                                <td>".$sn."</td>
                                <td>".$rows1['day']."</td>
                                <td>".$rows1['subject']."</td>
                                <td>".$rows1['faculty']."</td>
                                <td>".$rows1['start']."</td>
                                <td>".$rows1['end']."</td>
                                
                               </tr>";
                          }
                      }
                      else
                      {
                           echo   
                           "<div class='alert alert-danger' role='alert'>
                            No Record Found!
                            </div>";
                      }
                      
                      ?>
                    </tbody>
                    </table>
                    </div>

                    <div style="width: 30px;height:20px;" id="contact"></div>
                    <div class="boundry" style="overflow-y:scroll">
                    <div class="table-responsive p-3">
                    <form method="post">
                   <div>
                  <?php
                     
                     if (isset($_GET['Id']) && isset($_GET['action']) && $_GET['action'] == "edit")
                     {
                           $Id= $_GET['Id'];
                     
                           $query=mysqli_query($conn,"SELECT * FROM `user_data` WHERE `id`='$Id'");
                           $row=mysqli_fetch_array($query);
                      }
                     
                   

                    ?>
                   <div>
                        <label class="form-control-label">Date<span class="text-danger ml-2">*</span></label>
                        <input type="date" class="form-control" name="date"  id="exampleInputFirstName" >
                        </div>
                        <div>
                        <label class="form-control-label">Enrollment<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="Enrollment" value="<?php echo $row['ENROLLMENT'];?>" id="exampleInputFirstName" >
                        </div>
                    </div>
                    <div>
                    </div>  
                    </div>
                  
                    
                    <button type="submit" name="update" class="btn btn-warning">Update</button>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                   
                  </form>
                  <?php
                    if (isset($_POST['update']))
                    {
                          
                        $ENROLLMENT1=$_POST['Enrollment'];
                        $date2=$_POST['date'];
                        $date1 = date("Y-m-d", strtotime($date2));  
                        $day1=date('l', strtotime($date1));
                      echo $day1;
                      echo $date1;
                      echo $SEMESTER;
                        $sql5= "INSERT INTO `$ENROLLMENT1`( `DAY`, `DATE`, `SUBJECT`)
                            VALUES('$day1','$date1','$SEMESTER')";
                        $sql8= "INSERT INTO `$SEMESTER`( `DAY`, `DATE`, `enrollment`)
                            VALUES('$day1','$date1','$ENROLLMENT1')";
                        $result8=mysqli_query($conn, $sql5);
                        if($result8 = $conn->query($sql8)){
                                {
                                    echo  "Attendance Updated";
                               }
                            }
                         
                     }
                  ?>
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Enrollment</th>
                        
                         <th>Edit</th>
                        
                      </tr>
                    </thead>
                
                    <tbody>

                  <?php
                      $sql = "SELECT `UID`,`NAME`,`ENROLLMENT`,`id` FROM `user_data`";
                      $rs = mysqli_query($conn, $sql);
                      $num = mysqli_num_rows($rs);
                      $sn=0;
                      $status="";
                      if($num > 0)
                      { 
                        while ($rows = $rs->fetch_assoc())
                          {
                             $sn = $sn + 1;
                            echo"
                              <tr>
                                <td>".$sn."</td>
                                <td>".$rows['NAME']."</td>
                                <td>".$rows['ENROLLMENT']."</td>
                                
                                <td><a href='?action=edit&Id=".$rows['id']."'><i>edit</i></a></td>
                               </tr>";
                          }
                      }
                      else
                      {
                           echo   
                           "<div class='alert alert-danger' role='alert'>
                            No Record Found!
                            </div>";
                      }
                      
                      ?>
                    </tbody>
                  </table>
                </div>
                    </div>
                    <div style="width: 10px;height:70px;" >
                          </div>

                    
                     <!-- .projects-holder -->
                   


                </div>

            </div>
        </div>

        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/min/plugins.min.js"></script>
        <script src="js/min/main.min.js"></script>

    </body>
</html>