<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Student</title>
        <meta name="description" content="">
        <!-- 
    	Volton Template
    	http://www.templatemo.com/tm-441-volton
        -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/templatemo-style.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <?php
          
        ?>
        <?php
            session_start();
                $ENROLLMENT = $_SESSION['ENROLLMENT'] ;
                $name = $_SESSION['name'] ;
                $UID = $_SESSION['UID'] ;
                $DOB = $_SESSION['DOB'] ;
                $EMAIL = $_SESSION['EMAIL'] ;
                $CONTACT = $_SESSION['CONTACT'] ;
                $GENDER = $_SESSION['GENDER'] ;
                $DEPARTMENT = $_SESSION['DEPARTMENT'] ;
                $SEMESTER = $_SESSION['SEMESTER'] ;
                $ADDRESS = $_SESSION['ADDRESS'] ;
                $subject = $_SESSION['subject'];
                if(!isset($_SESSION['ENROLLMENT'])) //If user is not logged in then he cannot access the profile page
                {
                  //echo 'You are not logged in. <a href="login.php">Click here</a> to log in.';
                  header("location: ../../login.php");
                }
     //retrieve the session variable
        ?>
        <!-- SIDEBAR -->
        <div class="sidebar-menu">
            <div class="top-section">
                <div class="profile-image">
                    <img src="img/profile.png" style="margin:12px" alt="Volton">
                </div>
                <h3 class="profile-title" style="text-align:center"><?php echo $name;?></h3>
                <p class="profile-description" style="text-align:center"><?php echo $ENROLLMENT;?></p>
            </div> <!-- top-section -->
            <div class="main-navigation">
                <ul class="navigation" >
                    <li><a href="#top"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                    <li><a href="#report"><i class="fa fa-file-text"></i>Report</a></li>
                    <li><a href="#marks"><i class="fa fa-list-alt"></i>Mark</a></li>
                    <li><a href="#about"><i class="fa fa-user"></i>About Me</a></li>
                    <li><a href="#contact"><i class="fa fa-phone"></i>Contact us</a></li>
                </ul>
                <ul>
                    <li><a href="logout.php"><i class="fa fa-sign-out"></i>Logout</a></li>
                </ul>
            </div> <!-- .main-navigation -->
        </div> <!-- .sidebar-menu -->
        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="fluid-container">
                <div class="content-wrapper">
                    <!-- ABOUT -->
                    <div class="page-section">
                    
                            <div class="boundry" id="top">
                              <div class="right">
                                <h1><?php
                                  echo date("jS \of F Y") . "<br>";
                                  $day = date("l");
                                  echo  $day. "<br>";
                                ?></h1>
                                </div>
                                <h6 style="color:#143d59;font-size: 25px;">Today Time Table</h6>
                               <table class="table" style="color:#143d59">
                                 <tr>
                                   <th width="30%">Day</th>
                                   <td width="30%">09 to 10</td>
                                   <td width="30%">11 to 12</td>
                                 </tr>
                                 <tr>
                                   <th width="30%">
                                     <?php 
                                     echo $day;
                                     include '../../php/connection.php';
                                     $sql="SELECT `subject`, `faculty` FROM `timetable` WHERE `day`='$day'";
                                     if($day=='Sunday'){
                                      $sub="Holiday";
                                      $sub1="Holiday";
                                      $fac="Holiday";
                                      $fac1="Holiday";
                                     }
                                     elseif($day=='Saturday'){
                                      $sub="Holiday";
                                      $sub1="Holiday";
                                      $fac="Holiday";
                                      $fac1="Holiday";
                                     }
                                     if(($result = $conn->query($sql)))
                                     {
                                      while(($row = $result->fetch_assoc()))
                                      {
                                          $sub=$row['subject'];
                                          $fac=$row['faculty'];
                                      }
                                     }
                                     $sql1="SELECT `subject`, `faculty` FROM `timetable` WHERE `day`='$day' LIMIT 1";
                                     if(($result1 = $conn->query($sql1)))
                                     {
                                      while(($row1 = $result1->fetch_assoc()))
                                      {
                                          $sub1=$row1['subject'];
                                          $fac1=$row1['faculty'];
                                      }
                                     }
                                     ?></th>
                                   <td width="30%">
                                     <?php 
                                     echo $sub1;
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                     echo $sub;
                                     ?>
                                   </td>
                                 </tr>
                                 <tr>
                                   <th width="30%">Faculty</th>
                                   <td width="30%">
                                     <?php 
                                     echo $fac1;
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                     echo $fac;
                                     ?>
                                   </td>
                                 </tr>
                              </table>
                              <h6 style="color:#143d59;font-size: 25px;">Last Attendance</h6>
                               <table class="table" style="color:#143d59">
                                 <tr>
                                   <th width="30%">Day</th>
                                   <td width="30%">09 to 10</td>
                                   <td width="30%">11 to 12</td>
                                 </tr>
                                 <tr>
                                   <th width="30%">
                                     <?php 
                                  
                                     include '../../php/connection.php';
                                     $sql2="SELECT * FROM `$ENROLLMENT` WHERE id=(SELECT max(id) FROM `$ENROLLMENT`)";
                                     $result2 = $conn->query($sql2);
                                     while($row2 = $result2->fetch_assoc()){
                                     $date1=$row2['DATE'];
                                     $day1=$row2['DAY'];
                                     }
                                     echo $day1;
                                     $sql="SELECT `subject` FROM `timetable` WHERE `day`='$day1'";
                                     if(($result = $conn->query($sql)))
                                     {
                                      while(($row = $result->fetch_assoc()))
                                      {
                                          $sub2=$row['subject'];
                                    
                                      }
                                     }
                                     $sql1="SELECT `subject`, `faculty` FROM `timetable` WHERE `day`='$day1' LIMIT 1";
                                     if(($result1 = $conn->query($sql1)))
                                     {
                                      while(($row1 = $result1->fetch_assoc()))
                                      {
                                          $sub3=$row1['subject'];
                                      }
                                     }
                                     $sql3="SELECT * FROM `$ENROLLMENT` WHERE `DATE`='$date1'";
                                     if($result3 = $conn->query($sql3)){
                                     while($row3 = $result3->fetch_assoc()){
                                       $sub4=$row3['SUBJECT'];
                                     
                                     }
                                    }
                                    $sql4="SELECT * FROM `$ENROLLMENT` WHERE `DATE`='$date1' LIMIT 1";
                                     if($result4 = $conn->query($sql4)){
                                     while($row4 = $result4->fetch_assoc()){
                                       $sub5=$row4['SUBJECT'];
                                     
                                     }
                                    }
                                     ?></th>
                                   <td width="30%">
                                     <?php 
                                     echo $sub3;
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                     echo $sub2;
                                     ?>
                                   </td>
                                 </tr>
                                 <tr>
                                   <th width="30%">Attendance</th>
                                   <td width="30%">
                                     <?php 
                                     $cam=strcmp($sub5,$sub3);
                                     if($cam==0){
                                       echo "Present";
                                     }
                                     else{
                                       echo "Absent";
                                     }
                                     ?></td>
                                   <td width="30%">
                                   <?php 
                                   $cam=strcmp($sub2,$sub4);
                                    if($cam==0){
                                      echo "Present";
                                    }
                                    else{
                                      echo "Absent";
                                    }
                                     ?>
                                   </td>
                                 </tr>
                              </table>
                            </div>
                            <div style="width: 10px;height:20px;" id="report" >
                            
                          </div>
                           <div class="boundry" style="overflow-y:scroll">
                           <?php
                            $sql5="Select * from `$ENROLLMENT`";
                            $result5 = $conn->query($sql5);
                            echo "<table class='table'>";
                            echo "<tr>";
                            echo "<td width='30%'>Date</td>";
                            echo "<td width='30%''>Day</td>";
                            echo "<td width='30%'>Subject</td>";
                            echo "</tr>";
                            while($row5 = $result5->fetch_assoc()){
                            $date2=$row5['DATE'];
                            $day2=$row5['DAY'];
                            $sub6=$row5['SUBJECT'];
                            
                            echo "<tr>";
                            echo "<td width='30%'>".$date2."</td>";
                            echo "<td width='30%''>".$day2."</td>";
                            echo "<td width='30%'>".$sub6."</td>";
                            echo "</tr>";
                            
                            }
                            echo "</table>";

                            ?>
                            </div>
                            <div style="width: 30px;height:20px;" id="marks"></div>
                           <div class="boundry" >
                           <table class="table">
                             <?php
                             $result_sql=mysqli_query($conn,"SELECT * FROM `marks` WHERE `ENROLLMENT`='$ENROLLMENT'");
                             while($row = mysqli_fetch_assoc($result_sql))
                             {
                                 $p1 = $row['C'];
                                 $p2 = $row['C++'];
                                 $p3 = $row['PYTHON'];
                                 $p4 = $row['SQL'];
                                 $p5 = $row['JAVA'];
                                 $mark = $p1+$p2+$p3+$p4+$p5;
                                 $percentage = $mark/5;
                             }
                            ?>
                             <thead>
                               <tr>
                                <td> S.N </td>
                               <td colspan="10">Subjects </td>
                               <td rowspan="2"> Obtained Marks </td>
                             </tr>   
                            </thead>
                                  <tbody>
                                    <tr>
                                     <td> 1 </td>
                                     <td colspan="10">C </td>
                                     <td> <?php echo '<p>'.$p1.' / 100</p>';?> </td>
                                   </tr>

                                   <tr>
                                     <td> 2 </td>
                                     <td colspan="10">C++ </td>
                                     <td> <?php echo '<p>'.$p2.' / 100</p>';?></td>
                                   </tr>

                                   <tr>
                                     <td> 3 </td>
                                     <td colspan="10">PYTHON </td>
                                     <td> <?php echo '<p>'.$p3.' / 100</p>';?> </td>
                                    </tr>

                                   <tr>
                                     <td> 4 </td>
                                     <td colspan="10">SQL </td>
                                     <td> <?php echo '<p>'.$p4.' / 100</p>';?> </td>
                                    </tr>

                                    <tr>
                                     <td> 5 </td>
                                     <td colspan="10">JAVA </td>
                                     <td> <?php echo '<p>'.$p5.' / 100</p>';?> </td>
                                   </tr>
                                  </tbody>


                                  <tfoot>

                                      <tr>
                                      <td>#</td>
                                     <td colspan="10" class="footer">Total Marks Obtained</td>
                                      <td colspan="2"> <?php echo $mark;?> / 500 </td>
                                      </tr>

                                      <tr>
                                      <td colspan="10" class="footer">Percentage</td>
                                      <td colspan="2"><?php echo $percentage;?>% </td>
                                     </tr>

                                      <tr>
                                          <td colspan="10" class="footer">Student's Name</td>
                                          <td colspan="2"><?php echo $name;?> </td>
                                          </tr>

                                      <tr>
                                         <td colspan="10" class="footer">Semester</td>
                                         <td colspan="2"><?php echo $SEMESTER;?> </td>
                                          </tr>

                                          <tr>
                                         <td colspan="10" class="footer">Roll</td>
                                         <td colspan="2"><?php echo $ENROLLMENT;?> </td>
                                         </tr>
                                 </tfoot>
                               </table>
                            </div>
                            <div style="width: 30px;height:20px;" id="about"></div>
                            <div class="boundry" >
                                <h6 style="color:#143d59;font-size: 25px;">Personal Detail</h6>
                               <table class="table" style="color:#143d59">
                                 <tr>
                                   <th width="30%">Name</th>
                                   <td width="2%">:</td>
                                   <td><?php echo $name;?></td>
                                 </tr>
                                 <tr>
                                  <th width="30%">Enrllment Number	</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $ENROLLMENT;?></td>
                                </tr>
                                 <tr>
                                   <th width="30%">UID</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $UID;?></td>
                                </tr>
                                <tr>
                                 <th width="30%">Department</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $DEPARTMENT;?></td>
                                </tr>
                                <tr>
                                  <th width="30%"><?php echo $subject;?></th>
                                  <td width="2%">:</td>
                                  <td><?php echo $SEMESTER;?></td>
                                </tr>
                                <tr>
                                  <th width="30%">Date of Birth</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $DOB;?></td>
                                </tr>
                                <tr>
                                  <th width="30%">Gender</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $GENDER;?></td>
                                </tr>
                                <tr>
                                  <th width="30%">Email</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $EMAIL;?></td>
                                </tr>
                                <tr>
                                  <th width="30%">Contact</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $CONTACT;?></td>
                                </tr>
                                <tr>
                                  <th width="30%">Address</th>
                                  <td width="2%">:</td>
                                  <td><?php echo $ADDRESS;?></td>
                                </tr>
                              </table>
                        
                    </div>
                    
                    <div style="width: 30px;height:20px;" id="contact"></div>
                    <div class="boundry" >
                        <form action="/action_page.php">
                            <input type="text" id="fname" name="firstname" placeholder="Your name..">
                            <input type="text" id="lname" name="lastname" placeholder="Enrollment">
                            <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
                            <input type="submit" class="submit" value="Submit">
                        </form>
                    </div>
                    <div style="width: 10px;height:70px;" >
                          </div>

                    
                     <!-- .projects-holder -->
                   


                </div>

            </div>
        </div>

        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/min/plugins.min.js"></script>
        <script src="js/min/main.min.js"></script>

    </body>
</html>