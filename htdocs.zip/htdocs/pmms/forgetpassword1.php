<?php
include_once 'php/database.php';
require_once 'php/index.php';
if (isset($_POST['email'])) {
    $email2 = $_POST['email'];
    if (empty($email2)) {
        header("Location: forgetpassword.php?error= email is required");
        exit();
    }
    else{
        $sql1 = "SELECT * FROM user_data WHERE EMAIL='$email2'";
        $result1 = mysqli_query($conn, $sql1);
        if (mysqli_num_rows($result1) == 1) {
            $row = mysqli_fetch_assoc($result1);
            $enrollment1 = $row['ENROLLMENT'];
            $pass1 = $row['PASSWORD'];
            $name1 = $row['NAME'];
            email($enrollment1,$email2,$name1,$pass1);
            header("Location: thankyou.php");    
        }else{
            header("Location: forgetpassword.php?error=Incorect email id");
            exit();
        }
    }
}else{
    header("Location: forgetpassword.php");
    exit();
}
?>