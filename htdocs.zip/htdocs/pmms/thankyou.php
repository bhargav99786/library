<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Student registration form</title>
<link rel='stylesheet' href='css/form.css' type='text/css' />
<script src="js/form.js"></script>
</head>
<body onload="document.registration.enrollment.focus();">
    <div class="wrapper">
        <div class="inner">
            <form name='registration' action="login.php" method="post" enctype="multipart/form-data" >
                <h4 style="text-align: center; color: cornsilk;">
                    Yoy recieved user id and password in mail
                </h4>
                <button type="submit" class="zmdi zmdi-arrow-right" name="submit" value="Submit">ok </button>
            </form>
        </div>
    </div>
</body>
</html>