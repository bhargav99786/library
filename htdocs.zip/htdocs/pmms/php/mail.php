<!DOCTYPE html>
<html>
<body >
    <div style="max-width : 758px;
      margin: auto;
      background: #39459b;
      border: 10px solid #0d99d7;
      padding: 77px 99px 87px;
      box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -webkit-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -moz-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -ms-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -o-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);">
      <hr>
    
            <h1 style="text-align: center; color: cornflowerblue;">RFID Attemdance system</h1>
            <hr>
            <p style="color: cornflowerblue;">
                Your User id is :<br>
                Your Password is :
            </p>
            <h1 style="text-align: center; color: cornflowerblue; font-size: 15px;">Thank You</h1>
            <hr>
    </div>
</body>
</html>