<?php
include_once 'database.php';
$name = $_POST['username'];
$dob = $_POST['dateofbirth'];
$gender = $_POST['gender'];
$department = $_POST['department'];
$semester = $_POST['semester'];
$address = $_POST['Address'];
$enrollment = $_POST['enrollment'];
$email = $_POST['email'];
$mobile = $_POST['contact'];
require_once 'index.php';
function generate_password($enrollment,$email,$name){
  $chars = "0123456789";
  $password = substr( str_shuffle( $chars ), 0, 8 );
  return $password;
 }
 $pass = generate_password($enrollment,$email,$name);
$sql = "INSERT INTO user_data (NAME,ENROLLMENT,DOB,GENDER,EMAIL,CONTACT,DEPARTMENT,SEMESTER,ADDRESS,PASSWORD)
VALUES ('$name','$enrollment','$dob','$gender','$email','$mobile','$department','$semester','$address','$pass')";
$sql1 ="CREATE TABLE `$enrollment` (
   `id` int(255),
   `DAY` varchar(255),
   `DATE` date ,
   `SUBJECT` varchar(255));";
$sql2="ALTER TABLE `$enrollment`
ADD PRIMARY KEY (`id`),
MODIFY `id` int(255) AUTO_INCREMENT;";
$sql3="INSERT INTO `marks`(`ENROLLMENT`) VALUES ('$enrollment')";
if (mysqli_query($conn, $sql)) {
   mysqli_query($conn, $sql1);
   mysqli_query($conn, $sql2);
   mysqli_query($conn, $sql3);
   //mysqli_query($conn, $sql);
   echo "New record has been added successfully !";
   email($enrollment,$email,$name,$pass);
   header("Location: ../thankyou.php");
} else {
    echo "Error: " . $sql1 . ":-" . mysqli_error($conn);
   header("Location: ../thankyou1.php");
 }
 mysqli_close($conn);
?>