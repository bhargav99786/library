<?php
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  require 'PHPMailer/src/Exception.php';
  require 'PHPMailer/src/PHPMailer.php';
  require 'PHPMailer/src/SMTP.php';
  require_once 'connection.php';
 function email($enrollment,$email1,$name,$password){
  $mail = new PHPMailer(true);
  try {
      $mail->SMTPDebug = 2;                                       
      $mail->isSMTP();                                            
      $mail->Host       = 'smtp.gmail.com;';                    
      $mail->SMTPAuth   = true;                             
      $mail->Username   = 'bhargav.22102001@gmail.com';                 
      $mail->Password   = 'Bg@22102001';                        
      $mail->SMTPSecure = 'tls';                              
      $mail->Port       = 587;  
      $mail->setFrom('bhargav.22102001@gmail.com', 'RFID Attemdance system');       
      $mail->addAddress($email1, $name);       
      $mail->isHTML(true);                                  
      $mail->Subject = 'Rfid Attendance System';
      $mail->Body    = "
      <!DOCTYPE html>
<html>
<body >
    <div style='max-width : 758px;
      margin: auto;
      background: #39459b;
      border: 10px solid #0d99d7;
      padding: 77px 99px 87px;
      box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -webkit-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -moz-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -ms-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
      -o-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);'>
      <hr>
    
            <h1 style='text-align: center; color: cornflowerblue;'>RFID Attemdance system</h1>
            <hr>
            <p style='color: cornflowerblue;'>
                Your User id is :$enrollment <br>
                Your Password is : $password
            </p>
            <h1 style='text-align: center; color: cornflowerblue; font-size: 15px;'>Thank You</h1>
            <hr>
    </div>
</body>
</html>" ;
      $mail->AltBody = 'Body in plain text for non-HTML mail clients';
      $mail->send();
      
  } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
}
return 0;
?>