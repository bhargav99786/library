<?php 
session_start(); 
include "php/connection.php";
if (isset($_POST['uname']) && isset($_POST['password'])) {
    $uname = $_POST['uname'];
    $pass = $_POST['password'];
    if (empty($uname)) {
        header("Location: login.php?error=User Name is required");
        exit();
    }
    else if(empty($pass)){
        header("Location: login.php?error=Password is required");
        exit();
    }
    
    else
    {   
        $sql = "SELECT * FROM user_data WHERE ENROLLMENT='$uname' AND PASSWORD='$pass'";
        $result = mysqli_query($conn, $sql);
        $sql1 = "SELECT * FROM teacher_data WHERE ENROLLMENT='$uname' AND PASSWORD='$pass'";
        $result1 = mysqli_query($conn, $sql1);
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if ($row['ENROLLMENT'] === $uname && $row['PASSWORD'] === $pass) {
                echo "Logged in!";
                $_SESSION['ENROLLMENT'] = $row['ENROLLMENT'];
                $_SESSION['name'] = $row['NAME'];
                $_SESSION['UID'] = $row['UID'];
                $_SESSION['DOB'] = $row['DOB'];
                $_SESSION['EMAIL'] = $row['EMAIL'];
                $_SESSION['subject']="Semester";
                $_SESSION['CONTACT'] = $row['CONTACT'];
                $_SESSION['GENDER'] = $row['GENDER'];
                $_SESSION['DEPARTMENT'] = $row['DEPARTMENT'];
                $_SESSION['SEMESTER'] = $row['SEMESTER'];
                $_SESSION['ADDRESS'] = $row['ADDRESS'];
                if($uname=='admin'){
                    header("Location: ./portal/web/admin.php");
                }
                else{
                header("Location: ./portal/web/index.php");
                }
                exit();
            }
            else{
                header("Location: login.php?error=Incorect User name or password");
                exit();
            }
        }
        elseif (mysqli_num_rows($result1) === 1 ) {
            $row = mysqli_fetch_assoc($result1);
            if ($row['ENROLLMENT'] === $uname && $row['PASSWORD'] === $pass) {
                echo "Logged in!";
                $_SESSION['ENROLLMENT'] = $row['ENROLLMENT'];
                $_SESSION['name'] = $row['NAME'];
                $_SESSION['UID'] = $row['UID'];
                $_SESSION['DOB'] = $row['DOB'];
                $_SESSION['EMAIL'] = $row['EMAIL'];
                $_SESSION['subject']="Semester";
                $_SESSION['CONTACT'] = $row['CONTACT'];
                $_SESSION['GENDER'] = $row['GENDER'];
                $_SESSION['DEPARTMENT'] = $row['DEPARTMENT'];
                $_SESSION['SEMESTER'] = $row['SUBJECT'];
                $_SESSION['ADDRESS'] = $row['ADDRESS'];
                
                header("Location: ./portal/web/teacher.php");
               
                exit();
            }
            else{
                header("Location: login.php?error=Incorect User name or password");
                exit();
            }
        }
       
        else{
            header("Location: login.php?error=Incorect User name or password");
            exit();
        }
    }
}
else{
    header("Location: login.php");
    exit();
}
?>