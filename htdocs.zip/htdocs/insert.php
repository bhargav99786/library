<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "esp8266";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sector =array(1,2,4,5,6,8,9,10,12,13,14,16,17,18,20,21,22,24,25,26,28,29,30,32,33,34,36,37,38,40,41,42,44,45,46,48,49,50,52,53,54,56,57,58,60,61,62);
$len = count($sector);
for ($i=0; $i<=46; $i += 1) {
    if($i<1){ 
        $insert_string="`UID`,`".$insert_string.$sector[$i]."`,`";
    }   
    elseif($i<46){
        $insert_string=$insert_string.$sector[$i]."`,`";
    }
    elseif($i=46){
        $insert_string=$insert_string.$sector[$i]."`";
    }
}
include 'UIDContainer.php';
for ($i=0; $i<=46; $i += 1) {
    if($i<1){ 
        $insert_value="'".$UIDresult."',".$insert_value."'$"."a".$sector[$i]."',";
    }   
    elseif($i<46){
        $insert_value=$insert_value."'$"."a".$sector[$i]."',";
    }  
    elseif($i=46){
        $insert_value=$insert_value."'$"."a".$sector[$i]."'";
    }

}
function ascii($dec) {
	$n = strlen($dec);
	$result = "";
	for ($x=0; $x<=$n; $x += 2) {
		$temp = intval(substr($dec,$x,2));
		if($temp < 32) {
			$temp = intval(substr($dec,$x,3));
			if($temp > 128) {
			}
			$x++;
		}
		$result .= chr($temp);
	}
	return strval($result);
}
$val="'".$UIDresult."','".ascii($a1)."','".ascii($a2)."','".ascii($a4)."',
'".ascii($a5)."','".ascii($a6)."','".ascii($a8)."','".ascii($a9)."',
'".ascii($a10)."','".ascii($a12)."','".ascii($a13)."','".ascii($a14)."',
'".ascii($a16)."','".ascii($a17)."','".ascii($a18)."','".ascii($a20)."',
'".ascii($a21)."','".ascii($a22)."','".ascii($a24)."','".ascii($a25)."',
'".ascii($a26)."','".ascii($a28)."','".ascii($a29)."','".ascii($a30)."',
'".ascii($a32)."','".ascii($a33)."','".ascii($a34)."','".ascii($a36)."',
'".ascii($a37)."','".ascii($a38)."','".ascii($a40)."','".ascii($a41)."',
'".ascii($a42)."','".ascii($a44)."','".ascii($a45)."','".ascii($a46)."',
'".ascii($a48)."','".ascii($a49)."','".ascii($a50)."','".ascii($a52)."',
'".ascii($a53)."','".ascii($a54)."','".ascii($a56)."','".ascii($a57)."',
'".ascii($a58)."','".ascii($a60)."','".ascii($a61)."','".ascii($a62)."'";
echo $val;
$sql = "INSERT INTO mifare_data (".$insert_string.")
VALUES(".$val.")";
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>