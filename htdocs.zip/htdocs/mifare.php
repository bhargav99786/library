<?php
$mifare=$_POST["mifare"];
$Write="{\"mifare\":\"".$mifare."\"}";
file_put_contents('mifare.json',$Write);
$json_mifare_data = array("mifare"=>$mifare);
echo json_encode($json_mifare_data);
?>