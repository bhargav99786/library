String root_1 = doc["1"]; // "11297116101108"
String root_2 = doc["2"]; // "5765"
String root_4 = doc["4"]; // "109810497114103971112345678901234568"
String root_5 = doc["5"]; // "64"
String root_6 = doc["6"]; // "0000000000000000"
String root_8 = doc["8"]; // "0000000000000000"
String root_9 = doc["9"]; // "0000000000000000"
String root_10 = doc["10"]; // "0000000000000000"1234567890123456
String root_12 = doc["12"]; // "0000000000000000"1234567890123456
String root_13 = doc["13"]; // "0000000000000000"1234567890123456
String root_14 = doc["14"]; // "0000000000000000"1234567890123456
String root_16 = doc["16"]; // "0000000000000000"1234567890123456
String root_17 = doc["17"]; // "0000000000000000"1234567890123456
String root_18 = doc["18"]; // "0000000000000000"1234567890123456
String root_20 = doc["20"]; // "0000000000000000"1234567890123456
String root_21 = doc["21"]; // "0000000000000000"1234567890123456
String root_22 = doc["22"]; // "0000000000000000"1234567890123456
String root_24 = doc["24"]; // "0000000000000000"1234567890123456
String root_25 = doc["25"]; // "0000000000000000"1234567890123456
String root_26 = doc["26"]; // "0000000000000000"1234567890123456
String root_28 = doc["28"]; // "0000000000000000"1234567890123456
String root_29 = doc["29"]; // "0000000000000000"1234567890123456
String root_30 = doc["30"]; // "0000000000000000"1234567890123456
String root_32 = doc["32"]; // "0000000000000000"1234567890123456
String root_33 = doc["33"]; // "0000000000000000"1234567890123456
String root_34 = doc["34"]; // "0000000000000000"1234567890123456
String root_36 = doc["36"]; // "0000000000000000"1234567890123456
String root_37 = doc["37"]; // "0000000000000000"1234567890123456
String root_38 = doc["38"]; // "0000000000000000"1234567890123456
String root_40 = doc["40"]; // "0000000000000000"1234567890123456
String root_41 = doc["41"]; // "0000000000000000"1234567890123456
String root_42 = doc["42"]; // "0000000000000000"1234567890123456
String root_44 = doc["44"]; // "0000000000000000"1234567890123456
String root_45 = doc["45"]; // "0000000000000000"1234567890123456
String root_46 = doc["46"]; // "0000000000000000"1234567890123456
String root_48 = doc["48"]; // "0000000000000000"1234567890123456
String root_49 = doc["49"]; // "0000000000000000"1234567890123456
String root_50 = doc["50"]; // "0000000000000000"1234567890123456
String root_52 = doc["52"]; // "0000000000000000"1234567890123456
String root_53 = doc["53"]; // "0000000000000000"1234567890123456
String root_54 = doc["54"]; // "0000000000000000"1234567890123456
String root_56 = doc["56"]; // "0000000000000000"1234567890123456
String root_57 = doc["57"]; // "0000000000000000"1234567890123456
String root_58 = doc["58"]; // "0000000000000000"1234567890123456
String root_60 = doc["60"]; // "0000000000000000"1234567890123456
String root_61 = doc["61"]; // "0000000000000000"1234567890123456
String root_62 = doc["62"]; // "0000000000000000"1234567890123456
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 1 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(1 , buf1 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 2 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(2 , buf2 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 4 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(4 , buf4 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 5 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(5 , buf5 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 6 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(6 , buf6 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 8 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(8 , buf8 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 9 , &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(9 , buf9 , 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 10, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(10, buf10, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 12, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(12, buf12, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 13, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(13, buf13, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 14, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(14, buf14, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 16, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(16, buf16, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 17, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(17, buf17, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 18, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(18, buf18, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 20, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(20, buf20, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 21, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(21, buf21, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 22, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(22, buf22, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 24, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(24, buf24, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 25, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(25, buf25, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 26, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(26, buf26, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 28, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(28, buf28, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 29, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(29, buf29, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 30, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(30, buf30, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 32, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(32, buf32, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 33, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(33, buf33, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 34, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(34, buf34, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 36, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(36, buf36, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 37, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(37, buf37, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 38, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(38, buf38, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 40, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(40, buf40, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 41, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(41, buf41, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 42, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(42, buf42, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 44, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(44, buf44, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 45, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(45, buf45, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 46, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(46, buf46, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 48, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(48, buf48, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 49, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(49, buf49, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 50, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(50, buf50, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 52, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(52, buf52, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 53, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(53, buf53, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 54, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(54, buf54, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 56, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(56, buf56, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 57, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(57, buf57, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 58, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(58, buf58, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 60, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(60, buf60, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 61, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(61, buf61, 16);
Serial.println(F("MIFARE_Write() success: "));
status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 62, &key, &(mfrc522.uid));
Serial.println(F("PCD_Authenticate() success: "));
status = mfrc522.MIFARE_Write(62, buf62, 16);
Serial.println(F("MIFARE_Write() success: "));




INSERT INTO mifare_data (`UID`,
`1 `,
`2 `,
`4 `,
`5 `,
`6 `,
`8 `,
`9 `,
`10`,
`12`,
`13`,
`14`,
`16`,
`17`,
`18`,
`20`,
`21`,
`22`,
`24`,
`25`,
`26`,
`28`,
`29`,
`30`,
`32`,
`33`,
`34`,
`36`,
`37`,
`38`,
`40`,
`41`,
`42`,
`44`,
`45`,
`46`,
`48`,
`49`,
`50`,
`52`,
`53`,
`54`,
`56`,
`57`,
`58`,
`60`,
`61`,
`62`
)
VALUES('ec3cfb9a','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456','1234567890123456',
'1234567890123456');
