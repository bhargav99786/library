<?php
$Write = "{ \"1\":123}";
file_put_contents('data2.php',$Write);
?>