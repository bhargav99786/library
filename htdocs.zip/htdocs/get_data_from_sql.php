<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "esp8266";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
include 'UIDContainer.php';

$sql = "select * from mifare_data where UID ='$UIDresult'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $b1=$row["1"];
	$b2=$row["2"]; 
	$b4=$row["4"];
	$b5=$row["5"];
	$b6=$row["6"];
	$b8=$row["8"];
	$b9=$row["9"];
	$b10=$row["10"];
	$b12=$row["12"];
	$b13=$row["13"];
	$b14=$row["14"];
	$b16=$row["16"];
	$b17=$row["17"];
	$b18=$row["18"];
	$b20=$row["20"];
	$b21=$row["21"];
	$b22=$row["22"];
	$b24=$row["24"];
	$b25=$row["25"];
	$b26=$row["26"];
	$b28=$row["28"];
	$b29=$row["29"];
	$b30=$row["30"];
	$b32=$row["32"];
	$b33=$row["33"];
	$b34=$row["34"];
	$b36=$row["36"];
	$b37=$row["37"];
	$b38=$row["38"];
	$b40=$row["40"];
	$b41=$row["41"];
	$b42=$row["42"];
	$b44=$row["44"];
	$b45=$row["45"];
	$b46=$row["46"];
	$b48=$row["48"];
	$b49=$row["49"];
	$b50=$row["50"]; 
	$b52=$row["52"];
	$b53=$row["53"];
	$b54=$row["54"];
	$b56=$row["56"];
	$b57=$row["57"];
	$b58=$row["58"];
	$b60=$row["60"];
	$b61=$row["61"];
	$b62=$row["62"];

  }
} else {
  echo "0 results";
}



?>