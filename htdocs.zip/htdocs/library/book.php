<?php
require_once "database.php";
$subject_id = $_POST["subject_id"];
$semester_id = $_POST["semester_id"];
$result = mysqli_query($conn,"SELECT * FROM a where subject = '$subject_id' and semester ='$semester_id'");
?>
<option value="">Select Book</option>
<?php
while($row = mysqli_fetch_array($result)) {
?>
<option value="<?php echo $row["length"];?>"><?php echo $row["book"];?></option>
<?php
}
?>