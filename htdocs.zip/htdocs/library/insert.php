<?php
    if(isset($_POST['submit'])){
    include_once 'database.php';
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];
    $book = $_POST['book'];
    $position = $_POST['position'];
   

    $sql = "INSERT INTO book (semester,subject,book,length)
    VALUES ('$semester','$subject','$book','$position')";

    if (mysqli_query($conn, $sql)) {
    echo "<div style=color:green;align-content:'center'>New record has been added successfully !</div>";
   
    } else {
    echo "<div style=color:green;align-content:center>Error: " . $sql . ":-" . mysqli_error($conn)."</div>";
  
    }
    mysqli_close($conn);
}
    ?>