<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #000000;
  text-align: left;
  padding: 8px;
}
tr:nth-child(even) {
  background-color: #959596;
}
</style>
</head>
<body>
<?php
function ascii($dec) {
	$n = strlen($dec);
	$result = "";
	for ($x=0; $x<=$n; $x += 2) {
		$temp = intval(substr($dec,$x,2));
		if($temp < 32) {
			$temp = intval(substr($dec,$x,3));
			if($temp > 128) {
			}
			$x++;
		}
		$result .= chr($temp);
	}
	echo $result;
}
function data($row,$rowdata)
{
	echo "<tr><td>".$row."</td><td>"; 
	echo $rowdata;
	echo "<br>-----------------------<br>";
	ascii("$rowdata");
	echo "</td></tr>";
}

	include 'UIDContainer.php';
	echo "<table>";
	/*  
	$sector =array(1,2,4,5,6,8,9,10,12,13,14,16,17,18,20,21,22,24,25,26,28,29,30,32,33,34,36,37,38,40,41,42,44,45,46,48,49,50,52,53,54,56,57,58,60,61,62);
	$len = count($sector);
	for ($i=0; $i<=$len; $i += 1) {
		$j = $sector[$i];
		$str2=strval("a".$j);
		$int1=(int)$str2;
		data($j,$int1);
	}*/
	data("Sector","Detail");
	data("UID",$UIDresult);
	data("1",$a1);
	data("2",$a2);
	data("4",$a4);
	data("5",$a5);
	data("6",$a6);
	data("8",$a8);
	data("9",$a9);
	data("10",$a10);
	data("12",$a12);
	data("13",$a13);
	data("14",$a14);
	data("16",$a16);
	data("17",$a17);
	data("18",$a18);
	data("20",$a20);
	data("21",$a21);
	data("22",$a22);
	data("24",$a24);
	data("25",$a25);
	data("26",$a26);
	data("28",$a28);
	data("29",$a29);
	data("30",$a30);
	data("32",$a32);
	data("33",$a33);
	data("34",$a34);
	data("36",$a36);
	data("37",$a37);
	data("38",$a38);
	data("40",$a40);
	data("41",$a41);
	data("42",$a42);
	data("44",$a44);
	data("45",$a45);
	data("46",$a46);
	data("48",$a48);
	data("49",$a49);
	data("50",$a50);
	data("52",$a52);
	data("53",$a53);
	data("54",$a54);
	data("56",$a56);
	data("57",$a57);
	data("58",$a58);
	data("60",$a60);
	data("61",$a61);
	data("62",$a62);
	echo"</table>";
?>
<form action="mifare.php" method="get">
	<input type="checkbox" id="vehicle1" name="mifare" value="1">
	<label for="vehicle1"> Arr you sure write that data in Mifare card</label><br>
  	<input type="submit" value="Submit">
</form>
</body>
</html>