<?php
include 'UIDContainer.php';
include 'get_data_from_sql.php';

$Write1 = "\"{ \"1\":\"".$b1."\", \"2\":\"".$b2."\", \"4\":\"".$b4."\",\"5\":\"".$b5."\",\"6\":\"".$b6."\",\"8\":\"".$b8."\", \"9\":\"".$b9."\",\"10\":\"".$b10."\",\"12\":\"".$b12."\",\"13\":\"".$b13."\",\"14\":\"".$b14."\",\"16\":\"".$b16."\",\"17\":\"".$b17."\",\"18\":\"".$b18."\",\"20\":\"".$b20."\",\"21\":\"".$b21."\", \"22\":\"".$b22."\", \"24\":\"".$b24."\",\"25\":\"".$b25."\",\"26\":\"".$b26."\", \"28\":\"".$b28."\",\"29\":\"".$b29."\", \"30\":\"".$b30."\",\"32\":\"".$b32."\",\"33\":\"".$b33."\",\"34\":\"".$b34."\",\"36\":\"".$b36."\",\"37\":\"".$b37."\",\"38\":\"".$b38."\",\"40\":\"".$b40."\",\"41\":\"".$b41."\", \"42\":\"".$b42."\", \"44\":\"".$b44."\", \"45\":\"".$b45."\", \"46\":\"".$b46."\", \"48\":\"".$b48."\", \"49\":\"".$b49."\", \"50\":\"".$b50."\",\"52\":\"".$b52."\",\"53\":\"".$b53."\",\"54\":\"".$b54."\",\"56\":\"".$b56."\",\"57\":\"".$b57."\",\"58\":\"".$b58."\",\"60\":\"".$b60."\",\"61\":\"".$b61."\",\"62\":\"".$b62."\",\"UID\":\"".$UIDresult."\"}\"";

$arr = array('1'=> $b1 ,'2'=> $b2 ,'4'=> $b4 ,'5'=> $b5 ,'6'=> $b6 ,'8'=> $b8 ,'9'=> $b9 ,
'10'=> $b10 ,12 ,13 ,14 ,16 ,17 ,18 ,20 ,
21,22 ,24 ,25 ,26 ,28 ,29 ,30 ,
32,33 ,34 ,36 ,37 ,38 ,40 ,
41,42 ,44 ,45 ,46 ,48 ,49 ,50 ,
52,53 ,54 ,56 ,57 ,58 ,60 ,
61 ,62 ,UI=> $UIDresult );
echo json_encode($arr)."\n";

?>
    text1 =reader.read(1 )
    text2 =reader.read(2 )
    text4 =reader.read(4 )
    text5 =reader.read(5 )
    text6 =reader.read(6 )
    text8 =reader.read(8 )
    text9 =reader.read(9 )
    text10=reader.read(10)
    text12=reader.read(12)
    text13=reader.read(13)
    text14=reader.read(14)
    text16=reader.read(16)
    text17=reader.read(17)
    text18=reader.read(18)
    text20=reader.read(20)
    text21=reader.read(21)
    text22=reader.read(22)
    text24=reader.read(24)
    text25=reader.read(25)
    text26=reader.read(26)
    text28=reader.read(28)
    text29=reader.read(29)
    text30=reader.read(30)
    text32=reader.read(32)
    text33=reader.read(33)
    text34=reader.read(34)
    text36=reader.read(36)
    text37=reader.read(37)
    text38=reader.read(38)
    text40=reader.read(40)
    text41=reader.read(41)
    text42=reader.read(42)
    text44=reader.read(44)
    text45=reader.read(45)
    text46=reader.read(46)
    text48=reader.read(48)
    text49=reader.read(49)
    text50=reader.read(50)
    text52=reader.read(52)
    text53=reader.read(53)
    text54=reader.read(54)
    text56=reader.read(56)
    text57=reader.read(57)
    text58=reader.read(58)
    text60=reader.read(60)
    text61=reader.read(61)
    text62=reader.read(62)


"UIDresult='" . $UIDresult . "'; " 
     'aUIDresult':read.id,
	 'a1 ':text1 ,
	 'a2 ':text2 , 
	 'a4 ':text4 ,
	 'a5 ':text5 ,
	 'a6 ':text6 ,
	 'a8 ':text8 ,
	 'a9 ':text9 ,
	 'a10':text10,
	 'a12':text12,
	 'a13':text13,
	 'a14':text14,
	 'a16':text16,
	 'a17':text17,
	 'a18':text18,
	 'a20':text20,
	 'a21':text21,
	 'a22':text22,
	 'a24':text24,
	 'a25':text25,
	 'a26':text26,
	 'a28':text28,
	 'a29':text29,
	 'a30':text30,
	 'a32':text32,
	 'a33':text33,
	 'a34':text34,
	 'a36':text36,
	 'a37':text37,
	 'a38':text38,
	 'a40':text40,
	 'a41':text41,
	 'a42':text42,
	 'a44':text44,
	 'a45':text45,
	 'a46':text46,
	 'a48':text48,
	 'a49':text49,
	 'a50':text50, 
	 'a52':text52,
	 'a53':text53,
	 'a54':text54,
	 'a56':text56,
	 'a57':text57,
	 'a58':text58,
	 'a60':text60,
	 'a61':text61,
	 'a62':text62,
     