<html>
<body>
<form action="mifare.php" method="post">
	<input type="radio" id="vehicle1" name="mifare" value="1">
	<label for="vehicle1"> Are you sure write that data in Mifare card</label><br>
    <input type="radio" id="vehicle1" name="mifare" value="0">
	<label for="vehicle1"> Regular attendance Mode</label><br>
	<input type="radio" id="vehicle1" name="mifare" value="2">
	<label for="vehicle1"> read all dump info</label><br>
  	<input type="submit" value="Submit">
</form>
</body>
</html>